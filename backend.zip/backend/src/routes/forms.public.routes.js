import { Router } from "express";
import Form from "../models/Form.js";

const router = Router();

// Anyone can fetch a public form schema by publicId
router.get("/forms/:publicId", async (req, res) => {
  try {
    const { publicId } = req.params;
    const form = await Form.findOne({ publicId, isPublic: true }).lean();
    if (!form) return res.status(404).json({ error: "Form not found or not public" });

    // Return only what's needed for rendering/filling
    const payload = {
      title: form.title,
      publicId: form.publicId,
      baseId: form.baseId,
      tableId: form.tableId,
      tableName: form.tableName || "",
      questions: form.questions.map(q => ({
        fieldId: q.fieldId,
        fieldName: q.fieldName,
        fieldType: q.fieldType,
        label: q.label || q.fieldName,
        required: !!q.required,
        visibleWhen: q.visibleWhen || { logic: "all", rules: [] }
      }))
    };

    res.json(payload);
  } catch (err) {
    console.error("public form fetch error", err);
    res.status(500).json({ error: "Failed to load form" });
  }
});

export default router;
